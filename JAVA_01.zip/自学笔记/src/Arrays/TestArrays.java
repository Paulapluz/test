package Arrays;
import java.util.Arrays;
/**
 * ����Arr
 * @author HP
 *
 */
public class TestArrays {
	public static void main(String[] args) {
		int[] a = {100,20,35,150,80};
		
		System.out.println(a);
		
		System.out.println(Arrays.toString(a));
		
		Arrays.parallelSort(a);//������������
		System.out.println(Arrays.toString(a));
		
		System.out.println(Arrays.binarySearch(a, 35));
		
	}
}
