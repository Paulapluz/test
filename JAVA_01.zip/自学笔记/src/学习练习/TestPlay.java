package ѧϰ��ϰ;

public class TestPlay {
	public static void main(String[] args) {
		System.out.println("hello World!");
	}
}
