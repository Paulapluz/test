package ѧϰ��ϰ;

public class neibulei {
	public static void main(String[] args) {
		neibulei n = new neibulei();
		System.out.println(n.outer_i);
		n.test();
		
	}
	
	int outer_i = 100;
	void test() {
		inner in = new inner();
		in.display();
		System.out.println(in.a);
	}
	class inner{
		int a = 5;
		void display() {
			System.out.println("display:oter_i = "+ outer_i);
		}
	}
}
