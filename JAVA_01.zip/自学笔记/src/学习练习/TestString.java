package ѧϰ��ϰ;

public class TestString {
	
	public static void main(String args[]) {
		
		String a = new String("abc");
		String b = new String("abc");
		String c = "abc";
		System.out.println(a==b);
		System.out.println(a.equals(b));
		System.out.println(a == c);
		System.out.println(a.equals(c));
	}

}

class abc{
	private int abc = 233;
	
	
}