package ѧϰ��ϰ;

public class TestArrays {
	public static void main(String[] args) {
		char[] array01 = null;
		String[] array02 = null;
		User[] array03 = new User[10];
		int[] array04 = {1,1222,2,3,4};
		array01 = new char[10];
		array02 = new String[5];
		
		final int aa= 100;
		
		array03[0] = new User();
		array03[0].setId(123);
		array03[0].setName("Lover");
		
		
		array04 = new int[]{2,31231,4,2,22,2};//����һ����������
		
		
		System.out.println(array02[0]);
		System.out.println(array01[1]);
		System.out.println(array04[1]);
		System.out.println(array03[1]);
		System.out.println(array03[0].getId());
	}
}

class User {
	private int id;
	private String name;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
}