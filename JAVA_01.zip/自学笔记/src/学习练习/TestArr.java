package ѧϰ��ϰ;

public class TestArr {
	public static void main(String[] args) {
//		String[] s1 = {"aa","bb","cc","dd","ee"};
//		String[] s2 = {"AA","BB","CC","DD","EE"};
//		
//		Arr00(s1,3);
//		Arr00(s2, 2);
		
//		for(int i=0;i<s1.length;i++) {
//			System.out.println(i+"--"+s1[i]);
//		}
//		for(int i=0;i<s2.length;i++) {
//			System.out.println(i+"--"+s2[i]);
//		}
		
		
		extendRange();
		
		
	}
	
	public static String[] Arr00(String[] s,int index) {
		
		System.arraycopy(s, index, s, index-1,s.length-index);
		
		s[s.length-1] = null;
		
		return s;
	}

//���������(extendRange)
	public static void extendRange() {
	String[] s1 = {"aa","bb","cc"};
	
	String[] s2 = new String[s1.length+10];
	
	System.arraycopy(s1, 0, s2, 0, s1.length);
	
	for(String temp:s2) {
		System.out.println(temp);}
	}
	}
	
	
	
	
	
	
	
	
	