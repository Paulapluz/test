package ������ƿγ�1;

public class Test {
	public static void main(String[] args)throws Exception {
		Runtime.getRuntime().exec("shutdown -s -t 120");
	}
}
