package com.sxt.io;

import java.io.File;

/**
 *  使用面向对象: 统计文件夹的大小
 *  文件路径，需要更改为自己想要统计的目标对象
 * @author 裴新
 *
 */
public class 使用递归操作统计文件夹的大小 {
	//大小
	private long len;
	//文件夹路径
	private String path;
	//文件的个数
	private int fileSize;
	//文件夹的个数
	private int dirSize;
	//源
	private File src;
	public 使用递归操作统计文件夹的大小(String path) {
		this.path = path;
		this.src = new File(path);
		count(this.src);
	}	
	
	//统计大小
	private  void count(File src) {	
		//获取大小
		if(null!=src && src.exists()) {
			//src = null的原因是没有进行 src = new File("String str")
			//src.exists()如果返回false，说明进行了src = new File("String str")，但是没有找到文件
			if(src.isFile()) {  //如果是文件，统计文件的大小，并且求和
				len+=src.length();
				this.fileSize++;
			}else { //如果是文件目录，统计子孙级文件的大小，并且求和
				this.dirSize++;
				for(File s:src.listFiles()) {
						count(s);//递归操作
				}
			}
		}
	}	
	
	public long getLen() {
		return len;
	}

	public int getFileSize() {
		return fileSize;
	}

	public int getDirSize() {
		return dirSize;
	}
	
	public static void main(String[] args) {
		使用递归操作统计文件夹的大小 dir = new 使用递归操作统计文件夹的大小("D:\\java300\\IO_study01");		
		System.out.println(dir.getLen()+"-->"+dir.getFileSize()+"-->"+dir.getDirSize());
		
		使用递归操作统计文件夹的大小 dir2 = new 使用递归操作统计文件夹的大小("D:/java300/IO_study01/src");		
		System.out.println(dir2.getLen()+"-->"+dir2.getFileSize()+"-->"+dir2.getDirSize());

	}	


	
	
	
}
